package com.mycompany.poeprt3;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.swing.JOptionPane;

public class POEprt3 {
    private static String registeredUsername;
    private static String registeredPassword;
    private static int totalMessagesSent;
    private static int messageNumber;

    private static final Random RANDOM = new Random();
    private static final List<String> sentMessages = new ArrayList<>();
    private static final List<String> disregardedMessages = new ArrayList<>();
    private static final List<String> storedMessages = new ArrayList<>();
    private static final List<String> recipients = new ArrayList<>();
    private static final List<String> messageIDs = new ArrayList<>();
    private static final List<String> messageHashes = new ArrayList<>();

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat!");
        if (!registerUser()) {
            return;
        }

        if (loginUser()) {
            JOptionPane.showMessageDialog(null, "Login successful. Welcome to QuickChat!");
            runMainMenu();
        } else {
            JOptionPane.showMessageDialog(null, "Login failed. Exiting app.");
        }
    }

    private static boolean registerUser() {
        while (true) {
            String username = JOptionPane.showInputDialog(
                    "Create a username (must contain '_' and be no more than 5 characters):");
            if (username == null) {
                return false;
            }
            if (username.contains("_") && username.length() <= 5) {
                registeredUsername = username;
                break;
            }
            JOptionPane.showMessageDialog(null, "Invalid username.");
        }

        while (true) {
            String password = JOptionPane.showInputDialog(
                    "Create a password (8+ characters, including an uppercase letter, number, and special character):");
            if (password == null) {
                return false;
            }
            if (password.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$")) {
                registeredPassword = password;
                break;
            }
            JOptionPane.showMessageDialog(null, "Invalid password.");
        }

        while (true) {
            String phone = JOptionPane.showInputDialog("Enter a South African number (for example, +27782141765):");
            if (phone == null) {
                return false;
            }
            if (phone.matches("^\\+27[6-8]\\d{8}$")) {
                JOptionPane.showMessageDialog(null, "Registration successful!");
                return true;
            }
            JOptionPane.showMessageDialog(null, "Invalid phone number.");
        }
    }

    private static boolean loginUser() {
        for (int attempt = 0; attempt < 3; attempt++) {
            String username = JOptionPane.showInputDialog("Login - enter your username:");
            if (username == null) {
                return false;
            }
            String password = JOptionPane.showInputDialog("Enter your password:");
            if (password == null) {
                return false;
            }
            if (username.equals(registeredUsername) && password.equals(registeredPassword)) {
                return true;
            }
            JOptionPane.showMessageDialog(null, "Incorrect username or password.");
        }
        return false;
    }

    private static void runMainMenu() {
        boolean running = true;
        while (running) {
            String[] options = {"Send Messages", "Message Manager", "Quit"};
            int choice = JOptionPane.showOptionDialog(null, "Choose an option:", "Main Menu",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

            switch (choice) {
                case 0:
                    sendMessages();
                    break;
                case 1:
                    messageManagerMenu();
                    break;
                case 2:
                case JOptionPane.CLOSED_OPTION:
                    running = false;
                    JOptionPane.showMessageDialog(null, "Goodbye!");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice.");
            }
        }
    }

    private static void sendMessages() {
        String inputCount = JOptionPane.showInputDialog("How many messages would you like to send?");
        if (inputCount == null) {
            return;
        }

        final int count;
        try {
            count = Integer.parseInt(inputCount);
            if (count < 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Enter a valid non-negative number.");
            return;
        }

        for (int i = 0; i < count; i++) {
            String recipient = JOptionPane.showInputDialog("Enter recipient number (+27 followed by 9 digits):");
            if (recipient == null) {
                break;
            }
            if (!recipient.matches("^\\+27[6-8]\\d{8}$")) {
                JOptionPane.showMessageDialog(null, "Invalid number format.");
                i--;
                continue;
            }

            String message = JOptionPane.showInputDialog("Enter a message (maximum 250 characters):");
            if (message == null) {
                break;
            }
            if (message.length() > 250) {
                JOptionPane.showMessageDialog(null,
                        "Message is too long by " + (message.length() - 250) + " character(s).");
                i--;
                continue;
            }

            messageNumber++;
            String messageID = generateMessageID();
            String hash = generateMessageHash(messageID, messageNumber, message);
            String[] actions = {"Send", "Disregard", "Store"};
            int action = JOptionPane.showOptionDialog(null, "What do you want to do?", "Message Options",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, actions, actions[0]);

            switch (action) {
                case 0:
                    totalMessagesSent++;
                    sentMessages.add(message);
                    recipients.add(recipient);
                    messageIDs.add(messageID);
                    messageHashes.add(hash);
                    displayMessageDetails(messageID, hash, recipient, message);
                    JOptionPane.showMessageDialog(null, "Message successfully sent.");
                    break;
                case 1:
                    disregardedMessages.add(message);
                    JOptionPane.showMessageDialog(null, "Message disregarded.");
                    break;
                case 2:
                    storedMessages.add("Recipient: " + recipient + " | Message: " + message);
                    writeMessageToJSON(messageID, hash, recipient, message);
                    JOptionPane.showMessageDialog(null, "Message stored.");
                    break;
                default:
                    i--;
                    break;
            }
        }
        JOptionPane.showMessageDialog(null, "Total messages sent: " + totalMessagesSent);
    }

    private static void messageManagerMenu() {
        boolean running = true;
        while (running) {
            String[] options = {
                    "Display all sent messages", "Display longest message", "Search by Message ID",
                    "Search messages by recipient", "Delete message by hash", "Show full report", "Back to main menu"
            };
            int choice = JOptionPane.showOptionDialog(null, "Message Manager Options:", "Message Manager",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

            switch (choice) {
                case 0:
                    displaySenderAndRecipients();
                    break;
                case 1:
                    displayLongestMessage();
                    break;
                case 2: {
                    String id = JOptionPane.showInputDialog("Enter Message ID:");
                    if (id != null) {
                        searchByMessageID(id);
                    }
                    break;
                }
                case 3: {
                    String recipient = JOptionPane.showInputDialog("Enter recipient number:");
                    if (recipient != null) {
                        searchByRecipient(recipient);
                    }
                    break;
                }
                case 4: {
                    String hash = JOptionPane.showInputDialog("Enter Message Hash:");
                    if (hash != null) {
                        deleteByMessageHash(hash);
                    }
                    break;
                }
                case 5:
                    displayReport();
                    break;
                case 6:
                case JOptionPane.CLOSED_OPTION:
                    running = false;
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice.");
            }
        }
    }

    private static void displaySenderAndRecipients() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages to display.");
            return;
        }
        StringBuilder output = new StringBuilder();
        for (int i = 0; i < sentMessages.size(); i++) {
            output.append("Recipient: ").append(recipients.get(i)).append('\n')
                    .append("Message: ").append(sentMessages.get(i)).append('\n')
                    .append("Hash: ").append(messageHashes.get(i)).append('\n')
                    .append("ID: ").append(messageIDs.get(i)).append('\n')
                    .append("---------------------\n");
        }
        JOptionPane.showMessageDialog(null, output.toString(), "Sent Messages", JOptionPane.INFORMATION_MESSAGE);
    }

    private static void displayLongestMessage() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages.");
            return;
        }
        String longest = "";
        for (String message : sentMessages) {
            if (message.length() > longest.length()) {
                longest = message;
            }
        }
        JOptionPane.showMessageDialog(null, "Longest sent message:\n" + longest);
    }

    private static void searchByMessageID(String id) {
        for (int i = 0; i < messageIDs.size(); i++) {
            if (messageIDs.get(i).equals(id)) {
                JOptionPane.showMessageDialog(null,
                        "Recipient: " + recipients.get(i) + "\nMessage: " + sentMessages.get(i),
                        "Search Result", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Message ID not found.");
    }

    private static void searchByRecipient(String recipientNumber) {
        StringBuilder output = new StringBuilder("Messages to ").append(recipientNumber).append(":\n");
        boolean found = false;
        for (int i = 0; i < recipients.size(); i++) {
            if (recipients.get(i).equals(recipientNumber)) {
                output.append(sentMessages.get(i)).append('\n');
                found = true;
            }
        }
        for (String stored : storedMessages) {
            if (stored.startsWith("Recipient: " + recipientNumber + " |")) {
                output.append(stored).append('\n');
                found = true;
            }
        }
        if (found) {
            JOptionPane.showMessageDialog(null, output.toString(), "Messages by Recipient",
                    JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "No messages found for recipient: " + recipientNumber);
        }
    }

    private static void deleteByMessageHash(String hash) {
        for (int i = 0; i < messageHashes.size(); i++) {
            if (messageHashes.get(i).equals(hash)) {
                String message = sentMessages.remove(i);
                recipients.remove(i);
                messageIDs.remove(i);
                messageHashes.remove(i);
                JOptionPane.showMessageDialog(null, "Deleted message:\n" + message);
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Message hash not found.");
    }

    private static void displayReport() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages to report.");
            return;
        }
        StringBuilder output = new StringBuilder("==== SENT MESSAGE REPORT ====\n");
        for (int i = 0; i < sentMessages.size(); i++) {
            output.append("Message ID: ").append(messageIDs.get(i)).append('\n')
                    .append("Message Hash: ").append(messageHashes.get(i)).append('\n')
                    .append("Recipient: ").append(recipients.get(i)).append('\n')
                    .append("Message: ").append(sentMessages.get(i)).append('\n')
                    .append("---------------------\n");
        }
        JOptionPane.showMessageDialog(null, output.toString(), "Message Report", JOptionPane.INFORMATION_MESSAGE);
    }

    private static String generateMessageID() {
        return String.format("%010d", RANDOM.nextInt(1_000_000_000));
    }

    private static String generateMessageHash(String id, int number, String message) {
        String trimmed = message.trim();
        String[] words = trimmed.isEmpty() ? new String[0] : trimmed.split("\\s+");
        String first = words.length == 0 ? "" : words[0];
        String last = words.length == 0 ? "" : words[words.length - 1];
        return (id.substring(0, 2) + ":" + number + ":" + first + last).toUpperCase();
    }

    private static void displayMessageDetails(String id, String hash, String recipient, String message) {
        JOptionPane.showMessageDialog(null,
                "Message ID: " + id + "\nHash: " + hash + "\nRecipient: " + recipient + "\nMessage: " + message);
    }

    private static void writeMessageToJSON(String messageID, String hash, String recipient, String message) {
        String entry = "{\n"
                + "  \"MessageID\": \"" + escapeJSON(messageID) + "\",\n"
                + "  \"MessageHash\": \"" + escapeJSON(hash) + "\",\n"
                + "  \"Recipient\": \"" + escapeJSON(recipient) + "\",\n"
                + "  \"Message\": \"" + escapeJSON(message) + "\"\n"
                + "}";
        try {
            java.nio.file.Path path = Paths.get("Jsonnew.json");
            String existing = Files.exists(path)
                    ? new String(Files.readAllBytes(path), StandardCharsets.UTF_8).trim() : "";
            String json;
            if (existing.isEmpty() || existing.equals("[]")) {
                json = "[\n" + entry + "\n]\n";
            } else if (existing.endsWith("]")) {
                String contents = existing.substring(0, existing.length() - 1).trim();
                json = contents + (contents.equals("[") ? "\n" : ",\n") + entry + "\n]\n";
            } else {
                json = "[\n" + entry + "\n]\n";
            }
            try (FileWriter writer = new FileWriter(path.toFile(), false)) {
                writer.write(json);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing file: " + e.getMessage());
        }
    }

    private static String escapeJSON(String value) {
        StringBuilder escaped = new StringBuilder();
        for (int i = 0; i < value.length(); i++) {
            char character = value.charAt(i);
            switch (character) {
                case '"': escaped.append("\\\""); break;
                case '\\': escaped.append("\\\\"); break;
                case '\b': escaped.append("\\b"); break;
                case '\f': escaped.append("\\f"); break;
                case '\n': escaped.append("\\n"); break;
                case '\r': escaped.append("\\r"); break;
                case '\t': escaped.append("\\t"); break;
                default:
                    if (character < 0x20) {
                        escaped.append(String.format("\\u%04x", (int) character));
                    } else {
                        escaped.append(character);
                    }
            }
        }
        return escaped.toString();
    }
}
